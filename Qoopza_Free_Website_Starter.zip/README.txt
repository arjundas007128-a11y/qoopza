QOOPZA — FREE STARTER WEBSITE

FILES
- index.html: responsive shopping catalogue with product search and demo cart
- robots.txt: crawler access file (replace YOUR-SITE-URL)
- sitemap.xml: sitemap starter (replace YOUR-SITE-URL)

PUBLISH WITH GITHUB PAGES
1. Sign in to GitHub and create a PUBLIC repository named: qoopza
2. Upload index.html, robots.txt and sitemap.xml to the repository root.
3. Open Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Choose branch main and folder /(root), then Save.
6. Wait for the published site URL, usually https://YOUR-USERNAME.github.io/qoopza/

IMPORTANT
- Replace YOUR-SITE-URL in robots.txt and sitemap.xml with your exact published URL.
- Edit sample products/prices and add only products you are allowed to sell.
- This starter is a static demo catalogue. The cart is stored in the visitor's browser.
- It does NOT process payments, create real orders, manage stock, or provide an admin panel.
- Do not add personal phone/address details publicly. For real payments or selling, work with a parent/guardian and follow applicable rules.

GOOGLE SEARCH
1. Open https://search.google.com/search-console
2. Add your exact published URL as a URL-prefix property.
3. Verify ownership using the method Google offers for your hosting setup.
4. Submit sitemap.xml in the Sitemaps section.
5. Use URL Inspection on your homepage and choose Request indexing.
6. Later, search Google for: site:YOUR-PUBLISHED-URL

Google does not guarantee indexing or a particular ranking. Discovery/indexing can take days to weeks.
